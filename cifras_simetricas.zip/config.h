#define PROJECT_DIR "C:/Users/Nicolas/Desktop/security-project"
#define OUTPUT_DIR "C:/Users/Nicolas/Desktop/security-project/output"
#define INPUT_DIR "C:/Users/Nicolas/Desktop/security-project/input"    
